#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "devices/input.h"

#define STDIN 0
#define STDOUT 1

static void syscall_handler(struct intr_frame*);

struct description
{
	struct file* file;
	struct list_elem elem;
	int file_counter;
};

void
syscall_init(void)
{
	intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void exit_thrd(struct intr_frame* f) {
	f->eax = -1;
	thread_current()->ret = -1;
	thread_exit();
	return 1;
}

int useable_adress(const void* vaddr, struct intr_frame* f)
{
	if (is_user_vaddr(vaddr) && pagedir_get_page(thread_current()->pagedir, vaddr)) {
		return 0;
	}
	else {
		exit_thrd(f);
	}
}

struct file* threads_files(int desk) {

	struct list_elem* list_deskript = list_begin(&thread_current()->file_descriptors);

	while (list_deskript != list_end(&thread_current()->file_descriptors) && list_deskript != NULL) {

		if (list_entry(list_deskript, struct description, elem)->file_counter == desk) {
			return (list_entry(list_deskript, struct description, elem)->file);
		}

		list_deskript = list_next(list_deskript);
	}
	return NULL;
}



static void
syscall_handler(struct intr_frame* f)
{
	if (useable_adress((f->esp), f)) {
		return;
	}
	int syscall = *(int*)f->esp;
	ASSERT((syscall <= 19) && (syscall >= 0));
	int* args_for_syscall = f->esp;
	int* first_arg = *(args_for_syscall + 1);
	if(syscall==SYS_EXIT)
	{
		thread_current()->ret = first_arg;
		thread_exit();
		return;
	}
	else if (syscall == SYS_HALT)
	{
		shutdown_power_off();
		return;
	}
	else if (syscall == SYS_EXEC)
	{
		if (useable_adress(first_arg, f)) {
			return;
		}
		f->eax = process_execute(first_arg);
		return;
	}
	else if (syscall == SYS_WAIT)
	{
		if (useable_adress((args_for_syscall + 1), f)) {
			return;
		}
		f->eax = process_wait((args_for_syscall[1]));
		return;
	}
	else if (syscall == SYS_CREATE)
	{
		int* size = *(args_for_syscall + 2);
		if (useable_adress(first_arg, f) || useable_adress((args_for_syscall + 2), f)) {
			return;
		}
		f->eax = filesys_create(first_arg, size);
		return;
	}
	else if (syscall == SYS_REMOVE)
	{
		if (useable_adress(first_arg, f)) {
			return;
		}
		f->eax = filesys_remove(first_arg);
		return;
	}
	else if (syscall == SYS_OPEN)
	{
		if (useable_adress(first_arg, f)) {
			return;
		}

		struct file* file = filesys_open(first_arg);;
		if (!file) {
			f->eax = -1;
			return;
		}
		else
		{
			struct description* newdescription = (struct description*)malloc(sizeof(struct description));
			newdescription->file = file;
			newdescription->file_counter = thread_current()->numb_opend_files;
			thread_current()->numb_opend_files += 1;
			list_push_back(&thread_current()->file_descriptors, &newdescription->elem);
			f->eax = newdescription->file_counter;
			return;
		}
	}
	else if (syscall == SYS_CLOSE)
	{
		if (useable_adress((args_for_syscall + 1), f)) {
			return;
		}
		int source = first_arg;
		struct list_elem* list_descr = list_begin(&thread_current()->file_descriptors);
		while (list_descr != list_end(&thread_current()->file_descriptors)) {
			if (list_entry(list_descr, struct description, elem)->file_counter == source) {
				file_close(list_entry(list_descr, struct description, elem)->file);
				thread_current()->numb_opend_files--;
				list_entry(list_descr, struct description, elem)->file = NULL;
				return;
			}
			list_descr = list_next(list_descr);
		}
		exit_thrd(f);
	}
	else if (syscall == SYS_FILESIZE)
	{
		if ((useable_adress((args_for_syscall + 1), f))) {
			return;
		}
		int source = first_arg;
		struct file* tempfile;
		tempfile = threads_files(source);
		if (tempfile != NULL) {
			f->eax = file_length(tempfile);
			return;
		}
		exit_thrd(f);
	}
	else if (syscall == SYS_READ)
	{
		if (useable_adress((args_for_syscall + 1), f) || useable_adress(*(args_for_syscall + 2), f) || useable_adress((args_for_syscall + 3), f)) {
			return;
		}
		int description = first_arg;
		int size = *(args_for_syscall + 3);
		char* buffer = *(args_for_syscall + 2);
		if (description == STDIN) {
			f->eax = input_getc();
			return;
		}
		if (description != STDOUT) {
			struct file* tempfile;
			tempfile = threads_files(description);
			if (tempfile != NULL) {
				f->eax = file_read(tempfile, buffer, size);
				return;
			}
		}
		exit_thrd(f);
	}
	else if (syscall == SYS_WRITE)
	{
		if (useable_adress((args_for_syscall + 1), f) || useable_adress(*(args_for_syscall + 2), f) || useable_adress((args_for_syscall + 3), f)) {
			return;
		}
		int description = first_arg;
		int size = *(args_for_syscall + 3);
		char* buffer = *(args_for_syscall + 2);
		if (description == STDOUT) {
			putbuf(buffer, size);
			return;
		}
		else{
			struct file* tempfile;
			tempfile = threads_files(description);
			if (tempfile != NULL) {
				f->eax = file_write(tempfile, buffer, size);
				return;
			}
		}
		exit_thrd(f);
	}
	else {
		exit_thrd(f);
	}
}
