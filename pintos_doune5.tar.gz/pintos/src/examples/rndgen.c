#include <stdio.h>
#include <syscall.h>

unsigned int lcg(unsigned int *seed) {
    const unsigned int a = 1664525; // множитель
    const unsigned int c = 1013904223; // приращение
    *seed = (a * (*seed) + c);
    return *seed;
}

int main(int argc, char *argv[]) {

    int lower_bound = atoi(argv[1]);
    int upper_bound = atoi(argv[2]);
    int N = atoi(argv[3]);
    unsigned int seed = atoi(argv[4]);

    for (int i = 0; i < N; ++i) {
        unsigned int random_number = lcg(&seed);
        int mapped_number = lower_bound + (random_number % (upper_bound - lower_bound + 1));
        printf("%d ", mapped_number);
    }

    printf("\n");

    return 0;
}
