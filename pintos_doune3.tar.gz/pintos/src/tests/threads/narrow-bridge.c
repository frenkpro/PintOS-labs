#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"

int x = 0;
unsigned int dir_on_bridge = -1, car_to_left = 0, car_to_right = 0;
unsigned int car_on_bridge = 0;
unsigned int  n_car_left = 0, n_car_right = 0, e_car_left = 0, e_car_right = 0;
struct semaphore n_left, n_right, e_left, e_right;


// Called before test. Can initialize some synchronization objects.

void narrow_bridge_init(void)
{
    sema_init(&n_left, 0);
    sema_init(&n_right, 0);
    sema_init(&e_left, 0);
    sema_init(&e_right, 0);
}
int free_space(int amount_of_car) {
    if (amount_of_car > 1) return 0;
    else if (amount_of_car < 2) return 1;
}

void in_order(int* number, struct semaphore* car_sema) {
    (*number)++;
    sema_down(car_sema);
}

void arrive_bridge(enum car_priority prio, enum car_direction dir) {
    if (prio == car_normal && dir == dir_left) {
        if (!free_space(car_on_bridge) || dir_on_bridge == dir_right || !free_space(car_to_left)) {
            in_order(&n_car_left, &n_left);
        }
        else {
            car_to_left++;
            if (free_space(car_on_bridge) && (dir_on_bridge == dir_left || dir_on_bridge == -1)) {
                car_on_bridge++;
            }
            else {
                in_order(&n_car_left, &n_left);
            }
        }
    }
    else if (prio == car_normal && dir == dir_right) {
        if (!free_space(car_on_bridge) || dir_on_bridge == dir_left || !free_space(car_to_right)) {
            in_order(&n_car_right, &n_right);
        }
        else {
            car_to_right++;
            if (free_space(car_on_bridge) && (dir_on_bridge == dir_right || dir_on_bridge == -1)) {
                car_on_bridge++;
            }
            else {
                in_order(&n_car_right, &n_right);
            }
        }
    }
    else if (prio == car_emergency && dir == dir_left) {
        if (!free_space(car_on_bridge) || dir_on_bridge == dir_right) {
            in_order(&e_car_left, &e_left);
        }
        else {
            car_on_bridge++;
        }
    }
    else {
        if (!free_space(car_on_bridge) || dir_on_bridge == dir_left) {
            in_order(&e_car_right, &e_right);
        }
        else {
            car_on_bridge++;
        }
    }
}

void put_car(int* car_n, struct semaphore* side) {
    sema_up(side);
    (*car_n)--;
    car_on_bridge++;
}


void movement(int dir) {
    if (dir == dir_left)
    {
        if (e_car_left != 0) {
            put_car(&e_car_left, &e_left);
            if (e_car_left != 0) {
                put_car(&e_car_left, &e_left);
            }
            else if (e_car_left == 0 && n_car_left != 0) {
                put_car(&n_car_left, &n_left);
            }
        }
        else if (n_car_left != 0) {
            put_car(&n_car_left, &n_left);
            if (n_car_left != 0) {
                put_car(&n_car_left, &n_left);
            }
        }
    }
    else
    {
        if (e_car_right != 0) {
            put_car(&e_car_right, &e_right);
            if (e_car_right != 0) {
                put_car(&e_car_right, &e_right);
            }
            else if (e_car_right == 0 && n_car_right != 0) {
                put_car(&n_car_right, &n_right);
            }
        }
        else if (n_car_right != 0) {
            put_car(&n_car_right, &n_right);
            if (n_car_right != 0) {
                put_car(&n_car_right, &n_right);
            }
        }
    }
}

void exit_bridge(enum car_priority prio, enum car_direction dir) {
    if (car_on_bridge != 0) car_on_bridge--;
    if (car_on_bridge == 0) {
        if (e_car_left != 0 && dir == dir_right) {
            movement(dir_left);
        }
        else if (e_car_right != 0 && dir == dir_left) {
            movement(dir_right);
        }
        else if (e_car_left == 0 && e_car_right != 0) {
            movement(dir_right);
        }
        else if (e_car_right == 0 && e_car_left != 0) {
            movement(dir_left);
        }
        else if (n_car_left != 0 && dir == dir_right) {
            movement(dir_left);
        }
        else if (n_car_right != 0 && dir == dir_left) {
            movement(dir_right);
        }
        else if (n_car_left == 0 && n_car_right != 0) {
            movement(dir_right);
        }
        else if (n_car_left != 0 && n_car_right == 0) {
            movement(dir_left);
        }
    }
}

